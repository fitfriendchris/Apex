# APEX AI Agents — Deployment Guide
## 5 Edge Functions + Proxy + Config · Supabase · ~20 min setup

---

## What's Included

| Agent | Function | Endpoint | Model | Purpose |
|-------|----------|----------|-------|---------|
| NutriVision | `analyze-food` | `/functions/v1/analyze-food` | Haiku 4.5 | Food photo + text → macros |
| ProgramBuilder | `program-builder` | `/functions/v1/program-builder` | Sonnet 4.5 | User profile → full workout program |
| WeeklyAnalyst | `weekly-analyst` | `/functions/v1/weekly-analyst` | Sonnet 4.5 | 7-day data → progress report + calorie adjustment |
| CoachCopilot | `coach-copilot` | `/functions/v1/coach-copilot` | Sonnet 4.5 | Draft replies · risk scans · macro adjustments · client briefs |
| SmartOnboard | `smart-onboard` | `/functions/v1/smart-onboard` | Haiku 4.5 | Sales page chat → lead qualification + plan preview |
| — | `anthropic-proxy` | `/functions/v1/anthropic-proxy` | — | Secure relay keeping API key off client |
| — | `get-config` | `/functions/v1/get-config` | — | Serves runtime config (no secrets) |

---

## Step 1 — Run the SQL Migration

Open Supabase → SQL Editor and run `daily_ai_usage.sql`. This is idempotent (safe to re-run).

---

## Step 2 — Set Secrets

```bash
# Required
supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
supabase secrets set COACH_SECRET=your_coach_password          # NEVER returned to client
supabase secrets set ALLOWED_ORIGIN=https://apexcoaching.app   # CORS lockdown

# Stripe
supabase secrets set STRIPE_CORE_LINK=https://buy.stripe.com/...
supabase secrets set STRIPE_ELITE_LINK=https://buy.stripe.com/...
supabase secrets set STRIPE_VIP_LINK=https://buy.stripe.com/...
supabase secrets set STRIPE_DIAMOND_LINK=https://buy.stripe.com/...
supabase secrets set STRIPE_AI_BASIC_LINK=https://buy.stripe.com/...
supabase secrets set STRIPE_PORTAL_URL=https://billing.stripe.com/...

# Optional
supabase secrets set USDA_API_KEY=your_usda_key_here

# Feature flags (optional — all default to enabled except referrals/leaderboard)
supabase secrets set FEATURE_REFERRALS=true        # to enable
supabase secrets set FEATURE_LEADERBOARD=true      # to enable
```

---

## Step 3 — Deploy the Edge Functions

```bash
supabase functions deploy get-config
supabase functions deploy anthropic-proxy
supabase functions deploy analyze-food
supabase functions deploy program-builder
supabase functions deploy weekly-analyst
supabase functions deploy coach-copilot
supabase functions deploy smart-onboard
```

---

## Step 4 — Update Main HTML (goToCoachMode patch)

The integration patch reads the coach's entered password from `window._coachEnteredPassword`.
Find `goToCoachMode()` in `apex_v2_fixed.html` and add this one line where the coach logs in:

```javascript
async function goToCoachMode(enteredPassword) {
  // ... your existing logic ...
  window._coachEnteredPassword = enteredPassword;  // ← ADD THIS LINE
  isCoach = true;
  // ...
}
```

> **Why?** `get-config` no longer returns `COACH_SECRET` to the browser
> (that was a security bug — any anonymous visitor could call that endpoint
> and get the coach password). Coach auth is now 100% server-side: the entered
> password is sent as `X-Coach-Token` and validated by each edge function.
> A wrong password returns 401.

---

## Step 5 — Add the Integration Patch to HTML

Open `apex_v2_fixed.html` and paste the entire contents of `integration-patch.html`
**just before** the closing `</body>` tag.

---

## Step 6 — Add UI Hooks (Optional Polish)

### Program Builder — add to Workouts tab
```html
<div id="aiProgramContainer"></div>
<button id="aiProgramBtn" class="btn btn-gold" onclick="generateAIProgram()">
  🤖 AI Generate Program
</button>
```

### Coach Copilot — add to check-in review queue
```html
<button id="copilotDraftBtn_EMAIL_SANITIZED" class="btn btn-outline btn-sm"
  onclick="coachCopilotDraftResponse('CLIENT_EMAIL')">
  🤖 AI Draft Reply
</button>
```
> Note: button ID must replace `@` and `.` in email with `_`:
> `copilotDraftBtn_chris_example_com` for `chris@example.com`

### Risk Scan — add to coach dashboard
```html
<div id="riskScanResults"></div>
<button id="riskScanBtn" class="btn btn-outline btn-sm"
  onclick="runCoachRiskScan()" style="border-color:var(--red);color:var(--red)">
  🔍 AI Risk Scan
</button>
```

---

## Security Architecture

| What | How |
|------|-----|
| Anthropic API key | Server-side only — never in HTML or client JS |
| Coach secret | Server-side only — never returned by get-config |
| User auth | Supabase JWT validated by every agent function |
| CORS | Locked to `ALLOWED_ORIGIN` env var across all functions |
| Rate limiting | Server-side via `daily_ai_usage` table + free-tier block before table query |
| Model allowlist | `anthropic-proxy` rejects any model not in the allowed set |
| Input validation | All endpoints validate type, length, array structure before forwarding |

---

## Agent Details

### Agent 1 — NutriVision (`analyze-food`)
- Already wired — no extra UI needed
- `type: 'text'` (meal description) or `type: 'scan'` (base64 photo)
- Returns: `{ food: { name, calories, protein, fat, carb, fiber, sugar, sodium, serving, confidence, tips[] } }`
- Validates image `mediaType` before forwarding (jpeg/png/gif/webp only)

### Agent 2 — ProgramBuilder (`program-builder`)
- Requires Core tier or above (enforced server-side)
- Generates periodized 4–12 week programs (weeks clamped 2–12)
- Stored in localStorage for offline access

### Agent 3 — WeeklyAnalyst (`weekly-analyst`)
- Fixed: `weekNumber` now defaults to 1 (not 0) when `joinDate` is missing
- Recommends calorie adjustment using Haakonssen weight-trend methodology
- Returns `coachMessage` + `clientSummary` separately

### Agent 4 — CoachCopilot (`coach-copilot`)
- Coach-only (`X-Coach-Token` required)
- Four actions: `draft-response`, `risk-scan`, `macro-adjust`, `client-brief`
- Risk scan now reads from lf cache client-side — O(n) not O(7n)

### Agent 5 — SmartOnboard (`smart-onboard`)
- No auth required (public funnel)
- IP rate limited: 30 req/min, 20 msgs/session
- Fixed: `ipCounts` Map is now bounded to 5,000 entries (prevents memory growth)

---

## Cost Estimates (Claude API)

| Agent | Model | Avg tokens/call | Est. cost/call |
|-------|-------|----------------|----------------|
| analyze-food (text) | Haiku 4.5 | ~400 | $0.0004 |
| analyze-food (scan) | Haiku 4.5 | ~1,200 | $0.0012 |
| program-builder | Sonnet 4.5 | ~3,000 | $0.054 |
| weekly-analyst | Sonnet 4.5 | ~2,500 | $0.045 |
| coach-copilot | Sonnet 4.5 | ~2,000 | $0.036 |
| smart-onboard | Haiku 4.5 | ~600 | $0.0006 |

With 100 active clients running weekly analysis + daily food scans:
**Estimated monthly cost: ~$80–150 in API calls**

---

## Changes from v1.0

- **SECURITY**: `get-config` no longer returns `coachSecret`
- **SECURITY**: `anthropic-proxy` removed insecure `X-Session-Token` presence-only fallback
- **SECURITY**: CORS now uses `ALLOWED_ORIGIN` env var across ALL functions (was hardcoded in proxy)
- **SECURITY**: Free-tier rate limit now blocks before querying usage table (can't be bypassed by missing table)
- **BUG FIX**: `weekly-analyst` `weekNumber` = 0 edge case when `joinDate` missing → now defaults to 1
- **BUG FIX**: `program-builder` height units now explicitly labeled in prompt ("70 inches" not "70\"")
- **BUG FIX**: `analyze-food` now falls back to JWT email when `userEmail` not in request body
- **PERF**: `runCoachRiskScan()` is O(n) from cache — no longer fires 7 async DB calls per client
- **RELIABILITY**: `ipCounts` Map in `smart-onboard` is now bounded to prevent memory growth
- **MODELS**: Upgraded Sonnet `claude-sonnet-4-20250514` → `claude-sonnet-4-5-20250929`
- **FEATURES**: Feature flags in `get-config` now env-var controlled instead of hardcoded
- **SECURITY**: `analyze-food` validates image `mediaType` before forwarding to Anthropic
- **QUALITY**: Null guards added throughout `integration-patch.html`
- **SECURITY**: CTA button in SmartOnboard uses event listener (no inline onclick with dynamic data)
