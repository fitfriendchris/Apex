// supabase/functions/analyze-food/index.ts
// ─────────────────────────────────────────────────────────────────────────────
// AGENT 1 — NutriVision AI
// Analyzes food from plain text OR a base64 photo.
// Returns a structured macro breakdown the client logs directly.
//
// Deploy:
//   supabase functions deploy analyze-food
//
// Secrets needed (shared with anthropic-proxy):
//   supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
//   supabase secrets set ALLOWED_ORIGIN=https://apexcoaching.app
//
// Request body:
//   { type: 'text', meal: string, userEmail, userContext? }
//   { type: 'scan', image: { base64: string, mediaType: string }, userEmail, userContext? }
//
// Response:
//   { food: { name, calories, protein, fat, carb, fiber, sugar, sodium, serving, confidence, tips[] } }
// ─────────────────────────────────────────────────────────────────────────────

import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages";

const allowedOrigin = Deno.env.get("ALLOWED_ORIGIN") ?? "https://apexcoaching.app";
const corsHeaders = {
  "Access-Control-Allow-Origin": allowedOrigin,
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// ── System prompt: strict JSON-only food analyst ──────────────────────────────
const SYSTEM_PROMPT = `You are NutriVision, a precision sports-nutrition AI trained on USDA FoodData Central, 
Cronometer, and elite physique coach databases. You analyze food from descriptions or photos and return 
accurate macro breakdowns calibrated for bodybuilding and physique goals.

RULES:
- Always respond with ONLY valid JSON — no markdown, no explanation, no preamble.
- Estimate conservatively for weight/portion when not specified (better to under-log protein than over).
- Account for cooking method (grilled chicken ≠ fried chicken — oil adds calories).
- For restaurant meals, use the closest USDA or well-known brand equivalent.
- If the image is unclear or not food, return { "error": "Cannot identify food in image" }.
- Confidence: "high" (known item), "medium" (estimated), "low" (unclear/complex mixed dish).

JSON SCHEMA (respond with exactly this shape):
{
  "name": "string — clean food name, e.g. 'Grilled Chicken Breast 6oz'",
  "calories": number,
  "protein": number,
  "fat": number,
  "carb": number,
  "fiber": number,
  "sugar": number,
  "sodium": number,
  "serving": "string — e.g. '6oz / 170g' or '1 cup (240ml)'",
  "confidence": "high" | "medium" | "low",
  "tips": ["string — 1-2 short coaching tips relevant to this food and the user's goal"]
}`;

serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405, headers: corsHeaders });

  const anthropicKey = Deno.env.get("ANTHROPIC_API_KEY");
  if (!anthropicKey) {
    return jsonError("ANTHROPIC_API_KEY not configured", 500);
  }

  // ── Auth: validate Supabase JWT ──────────────────────────────────────────────
  const authHeader = req.headers.get("Authorization") ?? "";
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_ANON_KEY") ?? "",
    { global: { headers: { Authorization: authHeader } } }
  );
  const { data: { user } } = await supabase.auth.getUser();
  // Allow unauthenticated for guest/free tier — rate limit handled client-side

  // ── Parse body ───────────────────────────────────────────────────────────────
  let body: Record<string, unknown>;
  try { body = await req.json(); } catch {
    return jsonError("Invalid JSON body", 400);
  }

  const { type, meal, image, userEmail, userContext } = body as {
    type: "text" | "scan";
    meal?: string;
    image?: { base64: string; mediaType: string };
    userEmail?: string;
    userContext?: {
      weight?: number;
      goal?: string;
      phase?: string;
      calories?: number;
      protein?: number;
    };
  };

  if (!type || !["text", "scan"].includes(type)) return jsonError("type must be 'text' or 'scan'", 400);
  if (type === "text" && !meal?.trim()) return jsonError("meal text is required for type=text", 400);
  if (type === "scan" && (!image?.base64 || !image?.mediaType)) {
    return jsonError("image.base64 and image.mediaType required for type=scan", 400);
  }

  // ── Validate image mediaType ─────────────────────────────────────────────────
  const ALLOWED_MEDIA_TYPES = new Set(["image/jpeg", "image/png", "image/gif", "image/webp"]);
  if (type === "scan" && !ALLOWED_MEDIA_TYPES.has(image!.mediaType)) {
    return jsonError("image.mediaType must be image/jpeg, image/png, image/gif, or image/webp", 400);
  }

  // ── Build context-aware user prompt ─────────────────────────────────────────
  const ctxStr = userContext
    ? `\nUser context: ${userContext.weight ? `${userContext.weight}lbs` : ""} · goal: ${userContext.goal ?? "cut"} · phase: ${userContext.phase ?? "normal"} · daily targets: ${userContext.calories ?? "?"}kcal / ${userContext.protein ?? "?"}g protein.`
    : "";

  const userPrompt = type === "text"
    ? `Analyze this meal and return the macro breakdown as JSON.${ctxStr}\n\nMeal description: "${meal}"`
    : `Identify the food in this image and return the macro breakdown as JSON.${ctxStr}\nAssume a single standard serving unless multiple items are clearly visible.`;

  // ── Build Anthropic payload ──────────────────────────────────────────────────
  const messageContent: unknown[] = type === "scan"
    ? [
        { type: "image", source: { type: "base64", media_type: image!.mediaType, data: image!.base64 } },
        { type: "text", text: userPrompt }
      ]
    : [{ type: "text", text: userPrompt }];

  try {
    const res = await fetch(ANTHROPIC_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": anthropicKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",   // Fast + cheap for food scanning
        max_tokens: 512,
        system: SYSTEM_PROMPT,
        messages: [{ role: "user", content: messageContent }],
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error("Anthropic error:", errText);
      return jsonError("AI analysis failed", 502);
    }

    const aiData = await res.json();
    const rawText = aiData.content?.[0]?.text ?? "";

    // ── Parse JSON from AI response ──────────────────────────────────────────
    let food: Record<string, unknown>;
    try {
      const cleaned = rawText.replace(/```json\n?|```\n?/g, "").trim();
      food = JSON.parse(cleaned);
    } catch {
      console.error("Failed to parse AI food JSON:", rawText);
      return jsonError("AI returned unparseable response — try rephrasing", 422);
    }

    // If AI returned an error object
    if (food.error) return jsonError(String(food.error), 422);

    // ── Sanitise / coerce numeric fields ────────────────────────────────────
    const sanitized = {
      name:       String(food.name ?? "Unknown food"),
      calories:   Math.max(0, Math.round(Number(food.calories) || 0)),
      protein:    Math.max(0, Math.round(Number(food.protein)  || 0)),
      fat:        Math.max(0, Math.round(Number(food.fat)      || 0)),
      carb:       Math.max(0, Math.round(Number(food.carb)     || 0)),
      fiber:      Math.max(0, Math.round(Number(food.fiber)    || 0)),
      sugar:      Math.max(0, Math.round(Number(food.sugar)    || 0)),
      sodium:     Math.max(0, Math.round(Number(food.sodium)   || 0)),
      serving:    String(food.serving ?? "1 serving"),
      confidence: ["high", "medium", "low"].includes(String(food.confidence)) ? food.confidence : "medium",
      tips:       Array.isArray(food.tips) ? food.tips.slice(0, 2).map(String) : [],
      source:     "ai",
    };

    // ── Increment usage counter (non-fatal) ──────────────────────────────────
    const emailForTracking = userEmail ?? user?.email;
    if (emailForTracking) {
      try {
        const today = new Date().toISOString().split("T")[0];
        await supabase.rpc("increment_ai_usage", { p_email: emailForTracking, p_date: today });
      } catch { /* non-fatal */ }
    }

    return new Response(JSON.stringify({ food: sanitized }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (err) {
    console.error("analyze-food error:", err);
    return jsonError("Internal server error", 500);
  }
});

function jsonError(message: string, status: number) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
