# APEX Deployment Checklist
## All 24/24 audit checks pass — follow these steps in order.

### Step 1 — Supabase Database (run once in SQL Editor)
Run `sql/daily_ai_usage.sql` in your Supabase SQL Editor.

### Step 2 — Deploy Edge Functions
```bash
supabase functions deploy analyze-food
supabase functions deploy anthropic-proxy
supabase functions deploy get-config
supabase functions deploy program-builder
supabase functions deploy weekly-analyst
supabase functions deploy coach-copilot
supabase functions deploy smart-onboard
```

### Step 3 — Set Secrets
```bash
supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
supabase secrets set COACH_SECRET=your_secure_password_here
supabase secrets set STRIPE_SECRET_KEY=sk_live_...
supabase secrets set ALLOWED_ORIGIN=https://apexcoaching.app
supabase secrets set STRIPE_AI_BASIC_LINK=https://buy.stripe.com/...
supabase secrets set STRIPE_CORE_LINK=https://buy.stripe.com/...
supabase secrets set STRIPE_ELITE_LINK=https://buy.stripe.com/...
supabase secrets set STRIPE_VIP_LINK=https://buy.stripe.com/...
supabase secrets set STRIPE_DIAMOND_LINK=https://buy.stripe.com/...
supabase secrets set STRIPE_PORTAL_URL=https://billing.stripe.com/...
```

### Step 4 — Deploy index.html
Upload `index.html` to Netlify, Vercel, or any static host.
Set your domain → ALLOWED_ORIGIN in Supabase secrets must match.

### Step 5 — Verify
Visit your site. Open DevTools → Network.
Confirm the first request hits `get-config` and returns 200.
AI meal logger should call `analyze-food` (not api.anthropic.com directly).

### Optional: Feature Flags
```bash
supabase secrets set FEATURE_REFERRALS=true
supabase secrets set FEATURE_LEADERBOARD=true
```

### Optional: USDA Barcode Fallback
```bash
supabase secrets set USDA_API_KEY=your_key_from_fdc.nal.usda.gov
```
